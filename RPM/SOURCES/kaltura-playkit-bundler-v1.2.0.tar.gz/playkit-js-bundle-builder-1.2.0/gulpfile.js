#! /usr/bin/env node
const gulp = require('gulp');
const gulpif = require('gulp-if');
const concat = require('gulp-concat');
const header = require('gulp-header');
const order = require("gulp-order");
const mergeJson = require("gulp-merge-json");
const mergeStream = require('merge-stream');
const sourcemaps = require('gulp-sourcemaps');
const argv = require('yargs')
    .default('dest', "")
    .argv;

var bundleConfig = new Buffer(argv.config, 'base64').toString('ascii');
var saveToDest = false;
var jsDest = "";
if (argv.dest && argv.dest !== "undefined" && argv.dest !== true) {
    saveToDest = true;
    jsDest = new Buffer(argv.dest, 'base64').toString('ascii');
}

var bundlerName = argv.name;
var sourceRoot = new Buffer(argv.source, 'base64').toString('ascii');
var packageConfig = JSON.parse(bundleConfig.replace(/'/g, '"'));
var data = {
    sourceMap: "",
    bundle: "",
    i18n: ""
};
gulp.task('build', function () {
    var config = packageConfig;
    var params = getParams(config);
    var i18n = getI18nFiles(config);
    var stream = gulp.src(params.files)
        .pipe(order([
            sourceRoot + "/kaltura-ovp-player/**/*.js",
            sourceRoot + "/kaltura-tv-player/**/*.js",
            sourceRoot + "/**/*.js"
        ], {base: './'}))
        .pipe(sourcemaps.init({loadMaps: true}))
        .pipe(concat(bundlerName + '.min.js'))
        .pipe(header(params.header))
        .pipe(sourcemaps.write('.'))
        .pipe(gulpif(saveToDest, gulp.dest(jsDest)));

    var i18nStream = gulp.src(i18n)
        .pipe(mergeJson({fileName: bundlerName + '.i18n.json', jsonSpace:''}))
        .pipe(gulpif(saveToDest, gulp.dest(jsDest)));

    const mergedStream = mergeStream(stream, i18nStream);
    mergedStream.on('end', function () {
        console.log(JSON.stringify(data));
    });
    mergedStream.on('data', function (chunk) {

        var contents = chunk.contents.toString().trim();
        var encodedContent = new Buffer(contents).toString('base64');
        if (chunk.path.endsWith('min.js.map')) {
            data.sourceMap = encodedContent;
        }
        else if (chunk.path.endsWith('.min.js')) {
            data.bundle = encodedContent;
        }
        else if (chunk.path.endsWith('.i18n.json')) {
            data.i18n = encodedContent;
        }
    });
    mergedStream.on('error', function (err) {
        console.log(err)
    });

});

function getParams(config) {
    var bundlerHeader = '/**\n* Kaltura Player lib';
    var dependencies = Object.keys(config);
    var filesArray = [];
    dependencies.forEach(function (key) {
        var filePath = sourceRoot + "/" + key + "/" + config[key] + "/*.js";
        filesArray.push(filePath);
        bundlerHeader += '\n* ' + key + ' v' + config[key];
    });
    bundlerHeader += '\n*/\n';
    return {files: filesArray, header: bundlerHeader};
}

function getI18nFiles(config) {
    var dependencies = Object.keys(config);
    var filesArray = [];
    dependencies.forEach(function (key) {
        var i18nFilePath = sourceRoot + "/" + key + "/" + config[key] + "/translations/*.i18n.json";
        filesArray.push(i18nFilePath);
    });
    return filesArray;
}









