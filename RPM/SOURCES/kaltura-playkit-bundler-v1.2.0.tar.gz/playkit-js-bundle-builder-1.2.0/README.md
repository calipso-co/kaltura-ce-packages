# Bundle Builder API Server

The goal of this server is to create bundle content and its sours maps for playkit-js by givven configuration.

### Deployment
Please refer to [deployment document](bundle_builder_server_deployment.md)

### Copyright & License

All code in this project is released under the [AGPLv3 license](http://www.gnu.org/licenses/agpl-3.0.html) unless a different license for a particular library is specified in the applicable library path.

Copyright © Kaltura Inc. All rights reserved.
